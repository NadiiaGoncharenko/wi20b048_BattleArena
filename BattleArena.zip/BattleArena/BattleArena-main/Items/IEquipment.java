package Items;

import Pawn.Hero;

public interface IEquipment {
    public void use(Hero other);
}
